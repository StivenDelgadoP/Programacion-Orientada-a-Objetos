﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace segundo_herencia
{
    class CLIENTE:ENCARGO
    {
        string nombre;

        string direccion;

     
        
        
        //CREA UN METODO 

    }
}
