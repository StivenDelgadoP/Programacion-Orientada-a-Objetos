﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace segundo_herencia
{
    class ENCARGO
    {
        double encargoId;

        public double EncargoId
        {
            get { return encargoId; }
            set { encargoId = value; }
        }
        string fecha;

        public string Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }
        int valor;

        public int Valor
        {
            get { return valor; }
            set { valor = value; }
        }

       

    }

}
